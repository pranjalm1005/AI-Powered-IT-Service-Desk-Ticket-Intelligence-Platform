import json
import boto3
import os
import re

# ------------------------------
# AWS Clients
# ------------------------------
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
rds = boto3.client("rds-data", region_name="us-east-1")

# ------------------------------
# ENV
# ------------------------------
DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN = os.environ["DB_SECRET_ARN"]
DB_NAME = os.environ["DB_NAME"]

# Models
CLASSIFY_MODEL = "amazon.titan-text-express-v1"
EMBED_MODEL = "amazon.titan-embed-text-v1"

# Define allowed categories
ALLOWED_CATEGORIES = {
    "billing",
    "technical",
    "login_issue",
    "refund",
    "bug",
    "access_request",
    "general_support"
}


# -----------------------------------------------------
# ENHANCED CLASSIFIER WITH FALLBACK
# -----------------------------------------------------
def classify_text(text: str) -> str:
    """
    Enhanced classifier with:
    1. Strict prompt engineering
    2. Keyword fallback
    3. Validation
    """
    
    # KEYWORD-BASED FALLBACK (runs first for speed)
    text_lower = text.lower()
    
    # Keyword mappings
    keywords = {
        "login_issue": ["login", "password", "forgot password", "can't log in", "cannot access", "authentication", "mfa", "2fa", "username"],
        "technical": ["vpn", "network", "connection", "software", "installation", "crash", "error", "not working", "slow", "performance"],
        "billing": ["invoice", "payment", "charge", "bill", "pricing", "cost", "subscription", "renewal"],
        "refund": ["refund", "money back", "return", "reimburs", "cancel subscription"],
        "bug": ["bug", "broken", "glitch", "issue", "problem", "not functioning", "malfunction"],
        "access_request": ["access", "permission", "role", "privileges", "need access to", "grant access", "add me to"],
    }
    
    # Count keyword matches
    category_scores = {}
    for category, words in keywords.items():
        score = sum(1 for word in words if word in text_lower)
        if score > 0:
            category_scores[category] = score
    
    # If clear winner, return immediately
    if category_scores:
        best_category = max(category_scores, key=category_scores.get)
        if category_scores[best_category] >= 2:  # At least 2 keyword matches
            print(f"KEYWORD MATCH: {best_category} (score: {category_scores[best_category]})")
            return best_category
    
    # BEDROCK AI CLASSIFICATION (as backup)
    prompt = f"""You are a strict ITSM ticket classifier. You MUST respond with ONLY ONE of these exact words:

billing
technical
login_issue
refund
bug
access_request
general_support

RULES:
- Password/login problems → login_issue
- VPN/network/software/crashes → technical
- Invoice/payment issues → billing
- Money back requests → refund
- Application errors/glitches → bug
- Permission/access requests → access_request
- Everything else → general_support

User Issue:
{text}

Category (one word only):"""

    try:
        response = bedrock.invoke_model(
            modelId=CLASSIFY_MODEL,
            body=json.dumps({
                "inputText": prompt,
                "textGenerationConfig": {
                    "temperature": 0.0,
                    "maxTokenCount": 10,
                    "stopSequences": ["\n"]
                },
            })
        )
        
        output = json.loads(response["body"].read())
        raw = output["results"][0]["outputText"].strip().lower()
        
        # Clean the response
        raw = re.sub(r'[^a-z_]', '', raw)
        
        print(f"BEDROCK RAW OUTPUT: '{raw}'")
        
        # Validate against allowed categories
        if raw in ALLOWED_CATEGORIES:
            return raw
            
        # Try partial matching
        for category in ALLOWED_CATEGORIES:
            if category in raw or raw in category:
                print(f"PARTIAL MATCH: {category}")
                return category
                
    except Exception as e:
        print(f"BEDROCK ERROR: {e}")
    
    # If keyword match exists but wasn't strong enough, use it
    if category_scores:
        best = max(category_scores, key=category_scores.get)
        print(f"USING WEAK KEYWORD MATCH: {best}")
        return best
    
    # Final fallback
    print("FALLBACK TO general_support")
    return "general_support"


# -----------------------------------------------------
# Titan Embedding (unchanged)
# -----------------------------------------------------
def generate_embedding(text: str):
    """Generate embedding vector using Titan"""
    try:
        response = bedrock.invoke_model(
            modelId=EMBED_MODEL,
            body=json.dumps({"inputText": text.strip()})
        )
        output = json.loads(response["body"].read())
        return output["embedding"][:768]
    except Exception as e:
        print(f"EMBEDDING ERROR: {e}")
        return None


# -----------------------------------------------------
# SIMILAR TICKETS (FIXED - now includes resolution info)
# -----------------------------------------------------
def find_similar_tickets(embedding, category: str):
    """
    Find similar resolved tickets using vector similarity
    """
    
    if not embedding:
        return []
    
    # Convert embedding to PostgreSQL vector format
    v = "[" + ",".join(str(x) for x in embedding) + "]"
    
    sql = """
        SELECT 
            t.id::text,
            t.title,
            t.description,
            t.category,
            t.status,
            COALESCE(t.user_resolution_steps, 'No steps recorded') as user_steps,
            COALESCE(t.it_resolution_steps, 'No IT steps recorded') as it_steps,
            t.resolved_at,
            (e.embedding <=> CAST(:embed AS vector)) AS similarity_distance
        FROM ticket_embeddings e
        JOIN tickets t ON t.id = e.ticket_id
        WHERE 
            LOWER(t.category) = LOWER(:category)
            AND t.status = 'resolved'
        ORDER BY similarity_distance ASC
        LIMIT 5;
    """
    
    params = [
        {"name": "embed", "value": {"stringValue": v}},
        {"name": "category", "value": {"stringValue": category}},
    ]
    
    try:
        resp = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql,
            parameters=params
        )
    except Exception as e:
        print(f"SIMILAR TICKET ERROR: {e}")
        return []
    
    results = []
    for r in resp.get("records", []):
        # Convert distance to similarity score (0-1)
        distance = r[8].get("doubleValue", 1.0)
        similarity = max(0, 1 - distance)
        
        results.append({
            "ticket_id": r[0].get("stringValue", ""),
            "title": r[1].get("stringValue", ""),
            "description": r[2].get("stringValue", ""),
            "category": r[3].get("stringValue", ""),
            "status": r[4].get("stringValue", ""),
            "user_resolution_steps": r[5].get("stringValue", ""),
            "it_resolution_steps": r[6].get("stringValue", ""),
            "resolved_at": r[7].get("stringValue"),
            "similarity_score": round(similarity, 3),
        })
    
    return results


# -----------------------------------------------------
# MAIN HANDLER
# -----------------------------------------------------
def lambda_handler(event, context):
    """
    Main Lambda handler for ticket classification
    """
    
    print("CLASSIFY TICKET EVENT:", json.dumps(event))
    
    # Parse input
    if "body" in event:
        try:
            body = json.loads(event["body"])
        except:
            body = event
    else:
        body = event
    
    text = (body.get("ticket_text") or body.get("text") or "").strip()
    
    if not text:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "ticket_text is required"})
        }
    
    # Step 1: Classify ticket
    category = classify_text(text)
    print(f"FINAL CATEGORY: {category}")
    
    # Step 2: Generate embedding
    embedding = generate_embedding(text)
    
    # Step 3: Find similar tickets
    similar = []
    if embedding:
        similar = find_similar_tickets(embedding, category)
        print(f"FOUND {len(similar)} SIMILAR TICKETS")
    
    return {
        "statusCode": 200,
        "body": json.dumps({
            "category": category,
            "similar_tickets": similar
        })
    }