import json
import boto3
import os

rds = boto3.client("rds-data", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]

def safe(c):
    if not isinstance(c, dict):
        return None
    return c.get("stringValue") or c.get("longValue") or c.get("doubleValue")

def lambda_handler(event, context):

    print("EVENT:", event)

    # -----------------------------
    # Parse Query
    # -----------------------------
    if "body" in event:
        try:
            body = json.loads(event["body"])
            query = (body.get("query") or "").lower()
        except:
            query = ""
    else:
        query = (event.get("query") or "").lower()

    if not query:
        return {"statusCode": 400, "body": json.dumps({"error": "query required"})}

    # ------------------------------------------
    # ADVANCED SIMILARITY SEARCH (pg_trgm)
    # ------------------------------------------
    sql = """
        SELECT 
            id::text,
            title,
            description,
            category,
            status,
            resolved_at,
            created_at,

            -- fuzzy similarity scoring
            GREATEST(
                similarity(LOWER(title), :q),
                similarity(LOWER(description), :q)
            ) AS sim_score,

            -- keyword match booster
            CASE WHEN LOWER(title) LIKE :q_like OR LOWER(description) LIKE :q_like
                 THEN 0.20 ELSE 0 END AS keyword_boost,

            -- category booster (if the category name appears inside query)
            CASE WHEN LOWER(:q) LIKE LOWER(category) THEN 0.25 ELSE 0 END AS cat_boost

        FROM tickets
        WHERE
            similarity(LOWER(title), :q) > 0.1
            OR similarity(LOWER(description), :q) > 0.1
            OR LOWER(title) LIKE :q_like
            OR LOWER(description) LIKE :q_like
        
        ORDER BY 
            (GREATEST(similarity(LOWER(title), :q), similarity(LOWER(description), :q))
            + CASE WHEN LOWER(title) LIKE :q_like OR LOWER(description) LIKE :q_like THEN 0.20 ELSE 0 END
            + CASE WHEN LOWER(:q) LIKE LOWER(category) THEN 0.25 ELSE 0 END
            - CASE WHEN status = 'resolved' THEN 0 ELSE 0.1 END) DESC,

            resolved_at DESC NULLS LAST,

            created_at DESC
        LIMIT 10;
    """

    params = [
        {"name": "q", "value": {"stringValue": query}},
        {"name": "q_like", "value": {"stringValue": f"%{query}%"}}
    ]

    try:
        resp = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql,
            parameters=params
        )
    except Exception as e:
        print("ERROR:", e)
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}

    results = []
    for r in resp.get("records", []):
        results.append({
            "id": safe(r[0]),
            "title": safe(r[1]),
            "description": safe(r[2]),
            "category": safe(r[3]),
            "status": safe(r[4]),
            "resolved_at": safe(r[5]),
            "created_at": safe(r[6]),
            "similarity_score": float(safe(r[7]) or 0) + float(safe(r[8]) or 0) + float(safe(r[9]) or 0)
        })

    return {
        "statusCode": 200,
        "body": json.dumps({"similar_tickets": results})
    }
