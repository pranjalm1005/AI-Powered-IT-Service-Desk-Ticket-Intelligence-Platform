import json
import boto3
import os

# RDS Data API
rds = boto3.client("rds-data", region_name="us-east-1")
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]

EMBED_MODEL = "amazon.titan-embed-text-v1"
LLM_MODEL = "amazon.titan-text-lite-v1"


def safe(col):
    if not isinstance(col, dict):
        return None
    return (
        col.get("stringValue")
        or col.get("doubleValue")
        or col.get("longValue")
        or None
    )


def generate_embedding(text):
    """Generate 768-dim Titan embedding."""
    res = bedrock.invoke_model(
        modelId=EMBED_MODEL,
        body=json.dumps({"inputText": text})
    )
    data = json.loads(res["body"].read())
    return data["embedding"][:768]


def lambda_handler(event, context):

    print("EVENT:", event)

    # ---------------------------------------
    # Input parsing
    # ---------------------------------------
    ticket_id = None
    if "body" in event:
        try:
            ticket_id = json.loads(event["body"]).get("ticket_id")
        except:
            ticket_id = None
    else:
        ticket_id = event.get("ticket_id")

    if not ticket_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "ticket_id required"})
        }

    # ---------------------------------------
    # 1️⃣ Get current ticket
    # ---------------------------------------
    sql = """
        SELECT id::text, title, description, category
        FROM tickets
        WHERE id = :tid
        LIMIT 1;
    """
    params = [{"name": "tid", "value": {"stringValue": ticket_id}}]

    resp = rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
        parameters=params
    )

    rows = resp.get("records", [])
    if not rows:
        return {
            "statusCode": 404,
            "body": json.dumps({"error": "Ticket not found"})
        }

    r = rows[0]
    title = safe(r[1])
    description = safe(r[2])
    text_for_embed = f"{title}\n{description}"

    # ---------------------------------------
    # 2️⃣ Generate embedding
    # ---------------------------------------
    query_embed = generate_embedding(text_for_embed)

    # Convert to pgvector format
    vec = "[" + ",".join(str(x) for x in query_embed) + "]"

    # ---------------------------------------
    # 3️⃣ Search similar resolved tickets
    # ---------------------------------------
    sql_sim = """
        SELECT 
            t.id::text,
            t.title,
            t.description,
            t.resolution_steps,
            t.resolved_at,
            e.embedding <=> CAST(:query_vec AS vector) AS distance
        FROM ticket_embeddings e
        JOIN tickets t ON t.id = e.ticket_id
        WHERE t.resolved_at IS NOT NULL
        ORDER BY distance ASC
        LIMIT 5;
    """

    resp2 = rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql_sim,
        parameters=[
            {"name": "query_vec", "value": {"stringValue": vec}}
        ]
    )

    similar_raw = resp2.get("records", [])
    similar = []

    for row in similar_raw:
        similar.append({
            "id": safe(row[0]),
            "title": safe(row[1]),
            "description": safe(row[2]),
            "resolution_steps": safe(row[3]),
            "resolved_at": safe(row[4]),
            "similarity_score": float(row[5]["doubleValue"])
        })

    # ---------------------------------------
    # 4️⃣ Use best resolved ticket as context
    # ---------------------------------------
    resolution_context = ""
    if similar and similar[0].get("resolution_steps"):
        resolution_context = similar[0]["resolution_steps"]

    # ---------------------------------------
    # 5️⃣ Generate GenAI Suggested Fix
    # ---------------------------------------
    prompt = f"""
You are an IT support engineer.
The user issue is:

Issue:
{description}

Past resolved steps (if any):
{resolution_context}

Give the BEST possible solution in short bullet points.
"""

    llm_res = bedrock.invoke_model(
        modelId=LLM_MODEL,
        body=json.dumps({"inputText": prompt})
    )
    final = json.loads(llm_res["body"].read())

    suggestion = final["results"][0]["outputText"]

    # ---------------------------------------
    # Final Output
    # ---------------------------------------
    return {
        "statusCode": 200,
        "body": json.dumps({
            "ticket_id": ticket_id,
            "suggested_resolution": suggestion,
            "top_similar": similar
        })
    }
