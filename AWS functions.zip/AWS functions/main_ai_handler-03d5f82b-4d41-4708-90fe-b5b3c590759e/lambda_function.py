import os
import json
import base64
import boto3
from botocore.exceptions import ClientError

# --- env vars (set these in Lambda Console) ---
MODEL_ID = os.getenv("MODEL_ID", "amazon.nova-micro-v1:0")
CREATE_TICKET_LAMBDA = os.getenv("CREATE_TICKET_LAMBDA", "create_ticket_lambda")
UPLOAD_FILE_LAMBDA = os.getenv("UPLOAD_FILE_LAMBDA", "upload_file_lambda")
GET_ATTACHMENTS_LAMBDA = os.getenv("GET_ATTACHMENTS_LAMBDA", "get_ticket_attachments")
BEDROCK_REGION = os.getenv("BEDROCK_REGION", os.getenv("AWS_REGION", "us-east-1"))
# ----------------------------------------------

bedrock = boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)
lmb = boto3.client("lambda")

SYSTEM_PROMPT = """
You are an IT helpdesk classification engine.

Respond EXACT raw JSON only.
DO NOT use markdown.
DO NOT use ``` fences.
DO NOT say anything outside JSON.


ALLOWED JSON KEYS ONLY:
{
  "action": "create_ticket|upload_file|get_attachments|general_answer",
  "title": "string",
  "description": "string",
  "category": "technical|software|hardware|network|access|other",
  "ticket_id": "string",
  "file_base64": "string"
}

Rules:
- ALWAYS fill all keys.
- Always put empty string "" if a value does not apply.
- Classify category from user text.
- If user intent is create ticket → action=create_ticket
- If user intent is upload file → action=upload_file
- If user intent is get attachments → action=get_attachments
- Else → general_answer

Return ONLY JSON. Example output:

{"action":"create_ticket","title":"VPN issue","description":"VPN disconnects","category":"network","ticket_id":"","file_base64":""}

If response is not valid JSON → fix and output valid JSON.

"""


def _invoke_bedrock(user_text: str) -> dict:
    merged = (
        "You are an IT helpdesk classification engine.\n"
        "Return ONLY a valid JSON with these keys:\n"
        "{\n"
        '  \"action\": \"create_ticket|upload_file|get_attachments|general_answer\",\n'
        '  \"title\": \"string\",\n'
        '  \"description\": \"string\",\n'
        '  \"category\": \"technical|software|hardware|network|access|other\",\n'
        '  \"ticket_id\": \"string\",\n'
        '  \"file_base64\": \"string\"\n'
        "}\n\n"
        "Rules:\n"
        "- Classify category.\n"
        "- If creating ticket → action=create_ticket.\n"
        "- Always output valid JSON.\n\n"
        f"USER: {user_text}"
    )

    body = {
        "messages": [
            {
                "role": "user",
                "content": [{"text": merged}]
            }
        ],
        "inferenceConfig": {
            "maxTokens": 350,
            "temperature": 0
        }
    }

    resp = bedrock.invoke_model(modelId=MODEL_ID, body=json.dumps(body))
    payload = json.loads(resp["body"].read())

    # 🔍 Debug log for inspection
    print("---- RAW BEDROCK PAYLOAD ----")
    print(json.dumps(payload, indent=2))
    print("-----------------------------")

    # ✅ Parse nova-lite format safely
    try:
        text_block = payload["output"]["message"]["content"][0]["text"]
        if text_block.startswith("```"):
            text_block = text_block.replace("```json", "").replace("```", "").strip()
        return json.loads(text_block)
    except Exception as e:
        print(f"Parsing error: {e}")
        return {"action": "general_answer"}




def _invoke_lambda(func_name: str, payload: dict) -> dict:
    resp = lmb.invoke(
        FunctionName=func_name,
        InvocationType="RequestResponse",
        Payload=json.dumps(payload).encode("utf-8"),
    )
    if "Payload" in resp:
        raw = resp["Payload"].read()
        try:
            return json.loads(raw)
        except Exception:
            # some lambdas return raw body
            return {"raw": raw.decode("utf-8", errors="ignore")}
    return {}

def _friendly_error(msg: str) -> dict:
    return {
        "statusCode": 200,
        "body": json.dumps(
            {"message": f"⚠️ I hit a snag: {msg}. Please try again or provide more details."}
        ),
    }

def lambda_handler(event, context):
    try:
        body = event if isinstance(event, dict) else {}
        if "body" in body and isinstance(body["body"], str):
            body = json.loads(body["body"])

        # Expect user input in 'text', optional base64 in 'file_base64' for upload
        user_text = body.get("text", "").strip()
        if not user_text:
            return {
                "statusCode": 200,
                "body": json.dumps({"message": "👋 Tell me what you’d like to do."}),
            }

        # Let Claude decide the action + fields
        plan = _invoke_bedrock(user_text)

        action = plan.get("action", "general_answer")

        # ---- route actions ----
        if action == "create_ticket":
            title = plan.get("title") or user_text[:60]
            desc = plan.get("description") or user_text
            category = plan.get("category") or "other"

            payload = {"title": title, "description": desc, "category": category}
            result = _invoke_lambda(CREATE_TICKET_LAMBDA, payload)

            # create_ticket_lambda returns {"statusCode":200,"body":"{\"ticket_id\":\"...\"}"}
            try:
                ticket_id = json.loads(result.get("body", "{}")).get("ticket_id")
            except Exception:
                ticket_id = None

            if ticket_id:
                msg = f"✅ Ticket created successfully!\n• **ID:** `{ticket_id}`\n• **Title:** {title}\n• **Category:** {category}"
            else:
                return _friendly_error("I couldn't create the ticket")

            return {"statusCode": 200, "body": json.dumps({"message": msg})}

        elif action == "upload_file":
            # expect either the model extracted base64 OR user supplied base64 in event
            b64 = plan.get("file_base64") or body.get("file_base64")
            file_name = body.get("file_name", "uploaded_file.dat")
            ticket_id = plan.get("ticket_id") or body.get("ticket_id")

            if not (b64 and ticket_id):
                return _friendly_error(
                    "for upload I need both `ticket_id` and `file_base64`."
                )

            payload = {
                "user_id": "system",  # or pass real user if you have it
                "ticket_id": ticket_id,
                "file_name": file_name,
                "file_content_base64": b64,
            }
            result = _invoke_lambda(UPLOAD_FILE_LAMBDA, payload)

            # { "statusCode":200, "headers":..., "body":"{\"uploaded\": true, \"s3_key\": \"...\"}" }
            try:
                bodyObj = json.loads(result.get("body", "{}"))
                if isinstance(bodyObj, str):  # sometimes nested string
                    bodyObj = json.loads(bodyObj)
            except Exception:
                bodyObj = {}

            if bodyObj.get("uploaded"):
                msg = f"📎 File uploaded to ticket `{ticket_id}` successfully."
            else:
                return _friendly_error("upload failed")

            return {"statusCode": 200, "body": json.dumps({"message": msg})}

        elif action == "get_attachments":
            ticket_id = plan.get("ticket_id") or body.get("ticket_id")
            if not ticket_id:
                return _friendly_error("please provide a ticket_id.")

            result = _invoke_lambda(GET_ATTACHMENTS_LAMBDA, {"ticket_id": ticket_id})
            # body: {"attachments":[{"s3_key": "...", "file_name": "...", "download_url": "..."}]}
            try:
                payload = json.loads(result.get("body", "{}"))
            except Exception:
                payload = {}

            atts = payload.get("attachments", [])
            if not atts:
                msg = f"ℹ️ No attachments found for ticket `{ticket_id}`."
            else:
                lines = [
                    f"• **{a.get('file_name','file')}** → {a.get('download_url','(no url)')}"
                    for a in atts
                ]
                msg = f"📂 Attachments for `{ticket_id}`:\n" + "\n".join(lines)

            return {"statusCode": 200, "body": json.dumps({"message": msg})}

        else:
            # general answer via Claude
            return {
                "statusCode": 200,
                "body": json.dumps(
                    {
                        "message": "I can create tickets, upload files to a ticket, and list/download attachments. Try: 'create ticket my VPN drops every 5 minutes'."
                    }
                ),
            }

    except ClientError as ce:
        return _friendly_error(str(ce))
    except Exception as e:
        return _friendly_error(str(e))
