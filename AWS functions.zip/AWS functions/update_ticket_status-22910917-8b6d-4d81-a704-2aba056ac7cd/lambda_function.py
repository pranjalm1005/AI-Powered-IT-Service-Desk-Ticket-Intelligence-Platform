import json
import boto3
import os
from datetime import datetime

rds = boto3.client("rds-data")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]


def lambda_handler(event, context):

    # Parse event
    if "body" in event:
        try:
            body = json.loads(event["body"])
        except:
            body = {}
    else:
        body = event

    ticket_id = body.get("ticket_id")
    status = (body.get("status") or "").lower()
    admin_email = (body.get("admin_email") or "")
    user_steps = body.get("user_resolution_steps")
    it_steps = body.get("it_resolution_steps")

    # must be timestamp format
    last_update = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    # Validate
    if not ticket_id or not status:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "ticket_id and status are required"})
        }

    sql = """
        UPDATE tickets
        SET 
            status = :status,

            last_update = :last_update::timestamp,

            resolved_at = CASE 
                WHEN :status = 'resolved' THEN NOW()
                ELSE resolved_at
            END,

            resolved_by = CASE
                WHEN :status = 'resolved' THEN :admin_email
                ELSE resolved_by
            END,

            user_resolution_steps = CASE
                WHEN :user_steps IS NOT NULL THEN :user_steps
                ELSE user_resolution_steps
            END,

            it_resolution_steps = CASE
                WHEN :it_steps IS NOT NULL THEN :it_steps
                ELSE it_resolution_steps
            END

        WHERE id = :ticket_id;
    """

    params = [
        {"name": "ticket_id", "value": {"stringValue": ticket_id}},
        {"name": "status", "value": {"stringValue": status}},
        {"name": "admin_email", "value": {"stringValue": admin_email}},
        {"name": "last_update", "value": {"stringValue": last_update}},

        {"name": "user_steps",
         "value": {"stringValue": user_steps} if user_steps else {"isNull": True}},

        {"name": "it_steps",
         "value": {"stringValue": it_steps} if it_steps else {"isNull": True}},
    ]

    rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
        parameters=params
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Ticket updated successfully",
            "ticket_id": ticket_id,
            "new_status": status,
            "last_update": last_update
        })
    }
