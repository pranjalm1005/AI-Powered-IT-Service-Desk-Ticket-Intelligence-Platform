import json
import boto3
import os
import time

rds = boto3.client("rds-data", region_name="us-east-1")
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]


def safe(col):
    if not isinstance(col, dict):
        return None
    return col.get("stringValue") or col.get("longValue") or col.get("doubleValue")


def lambda_handler(event, context):

    start_time = time.time()
    print("EVENT:", event)

    ticket_id = event.get("ticket_id")
    if not ticket_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "ticket_id is required"})
        }

    # -------------------------------------------------
    # 1️⃣ FETCH TICKET DATA
    # -------------------------------------------------
    sql = """
        SELECT id::text, title, description, category
        FROM tickets
        WHERE id = :tid
    """

    rows = rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
        parameters=[{"name": "tid", "value": {"stringValue": ticket_id}}]
    ).get("records", [])

    if not rows:
        return {
            "statusCode": 404,
            "body": json.dumps({"error": "Ticket not found"})
        }

    t = rows[0]
    ticket_title = safe(t[1])
    ticket_desc  = safe(t[2])
    category     = safe(t[3])

    # -------------------------------------------------
    # 2️⃣ FETCH RECENT RESOLVED TICKETS
    # -------------------------------------------------
    sql2 = """
        SELECT id::text, title, description, category, it_resolution_steps
        FROM tickets
        WHERE resolved_at IS NOT NULL
        ORDER BY resolved_at DESC
        LIMIT 10;
    """

    resolved = rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql2
    ).get("records", [])

    resolved_snippets = []
    for row in resolved:
        rid   = safe(row[0])
        title = safe(row[1])
        steps = safe(row[4]) or "No steps logged."

        resolved_snippets.append(f"[{rid}] {title} → {steps[:120]}...")

    resolved_text = "\n".join(resolved_snippets[:5])

    # -------------------------------------------------
    # 3️⃣ BUILD PROMPT FOR BEDROCK
    # -------------------------------------------------
    prompt = f"""
Ticket:
Title: {ticket_title}
Description: {ticket_desc}
Category: {category}

Based on PAST resolved tickets below, provide a VERY SHORT resolution (5–6 lines max).

Past Resolutions:
{resolved_text}

Keep the answer short and professional.
"""

    # -------------------------------------------------
    # 4️⃣ BEDROCK CALL (CORRECT TITAN FORMAT)
    # -------------------------------------------------
    try:
        print("Calling Bedrock...")

        bedrock_body = {
            "inputText": prompt,
            "textGenerationConfig": {
                    "maxTokenCount": 180,
                    "temperature": 0.3,
                    "stopSequences": ["User:"]   # Titan-allowed stop sequence
                }

        }

        resp = bedrock.invoke_model(
            modelId="amazon.titan-text-express-v1",
            body=json.dumps(bedrock_body),
            contentType="application/json",
            accept="application/json"
        )

        response_json = json.loads(resp["body"].read())
        result = response_json["results"][0]["outputText"]

    except Exception as e:
        print("Bedrock ERROR:", str(e))
        result = "Unable to generate resolution steps at the moment."

    # -------------------------------------------------
    # 5️⃣ FINAL RESPONSE
    # -------------------------------------------------
    return {
        "statusCode": 200,
        "body": json.dumps({
            "ticket_id": ticket_id,
            "suggested_resolution": result[:600],
            "response_time_sec": round(time.time() - start_time, 2)
        })
    }
