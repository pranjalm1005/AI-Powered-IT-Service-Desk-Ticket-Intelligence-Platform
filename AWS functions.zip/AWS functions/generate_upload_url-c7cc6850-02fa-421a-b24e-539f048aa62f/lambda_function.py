import boto3
import json
import uuid
import time

s3 = boto3.client("s3")

BUCKET = "agentic-ticket-attachments"

def lambda_handler(event, context):

    # always compute expiration from REAL server time (not user's event timestamp)
    expires_in_seconds = 3600   # 1 hour

    # generate random file key
    file_key = f"attachments/{uuid.uuid4()}"

    # force expiration from NOW (this line is the real fix)
    expiration_timestamp = int(time.time()) + expires_in_seconds

    signed_url = s3.generate_presigned_url(
        ClientMethod='put_object',
        Params={'Bucket': BUCKET, 'Key': file_key},
        ExpiresIn=expires_in_seconds
    )

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "upload_url": signed_url,
            "file_path": file_key,
            "expires_at_epoch": expiration_timestamp  # just to confirm
        })
    }
