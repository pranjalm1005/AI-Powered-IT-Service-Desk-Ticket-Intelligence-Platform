import json
import boto3
import os

rds = boto3.client("rds-data", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]


def safe(col):
    if not isinstance(col, dict):
        return None
    return (
        col.get("stringValue")
        or col.get("longValue")
        or col.get("doubleValue")
        or None
    )


def lambda_handler(event, context):

    print("EVENT:", event)

    # Parse ticket ID
    ticket_id = None
    if "body" in event:
        try:
            ticket_id = json.loads(event["body"]).get("ticket_id")
        except:
            pass
    else:
        ticket_id = event.get("ticket_id")

    if not ticket_id:
        return {"statusCode": 400, "body": json.dumps({"error": "ticket_id is required"})}

    # --------------------------------
    # Fetch ticket details
    # --------------------------------
    sql_ticket = """
        SELECT 
            id::text,
            title,
            description,
            category,
            status,
            user_email,
            created_at,
            updated_at,
            resolved_at,
            last_update
        FROM tickets
        WHERE id = :tid
        LIMIT 1;
    """

    params_ticket = [{"name": "tid", "value": {"stringValue": ticket_id}}]

    try:
        resp_ticket = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql_ticket,
            parameters=params_ticket
        )
    except Exception as e:
        print("ERROR fetching ticket:", e)
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}

    rows = resp_ticket.get("records", [])
    if not rows:
        return {"statusCode": 404, "body": json.dumps({"error": "Ticket not found"})}

    r = rows[0]
    ticket = {
        "id": safe(r[0]),
        "title": safe(r[1]),
        "description": safe(r[2]),
        "category": safe(r[3]),
        "status": safe(r[4]),
        "user_email": safe(r[5]),
        "created_at": safe(r[6]),
        "updated_at": safe(r[7]),
        "resolved_at": safe(r[8]),
        "last_update": safe(r[9])
    }

    # --------------------------------
    # Fetch attachments (correct filter on s3_key)
    # --------------------------------
    sql_attach = """
        SELECT 
            id::text,
            file_name,
            s3_key,
            uploaded_at
        FROM attachments
        WHERE s3_key LIKE CONCAT('%', :tid, '%')
        ORDER BY uploaded_at DESC;
    """

    attachments = []
    try:
        resp_attach = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql_attach,
            parameters=params_ticket
        )

        for row in resp_attach.get("records", []):
            attachments.append({
                "id": safe(row[0]),
                "file_name": safe(row[1]),
                "s3_key": safe(row[2]),
                "uploaded_at": safe(row[3])
            })

    except Exception as e:
        print("ERROR fetching attachments:", e)

    ticket["attachments"] = attachments

    return {
        "statusCode": 200,
        "body": json.dumps({"ticket": ticket})
    }
