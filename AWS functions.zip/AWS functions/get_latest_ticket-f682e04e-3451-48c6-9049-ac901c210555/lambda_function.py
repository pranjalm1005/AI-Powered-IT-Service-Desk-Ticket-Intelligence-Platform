import json
import boto3
import os

# Explicit region (important for some Lambda/RDS setups)
rds = boto3.client("rds-data", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]  # e.g., "postgres"


def safe(col):
    """Safely extract a value from an RDS column object."""
    if not isinstance(col, dict):
        return None
    return (
        col.get("stringValue")
        or col.get("longValue")
        or col.get("doubleValue")
        or None
    )


def lambda_handler(event, context):

    print("RAW EVENT:", json.dumps(event))

    # --------------------------
    # Parse body
    # --------------------------
    if "body" in event:
        try:
            body = json.loads(event["body"])
        except:
            body = {}
    else:
        body = event or {}

    category = (body.get("category") or "").strip().lower()
    print("CATEGORY:", category)

    # --------------------------
    # Build SQL
    # --------------------------
    if category:
        sql = """
            SELECT 
                id::text,
                title,
                description,
                category,
                created_at
            FROM tickets
            WHERE LOWER(category) = :cat
            ORDER BY created_at DESC
            LIMIT 1;
        """
        params = [
            {"name": "cat", "value": {"stringValue": category}}
        ]
    else:
        sql = """
            SELECT 
                id::text,
                title,
                description,
                category,
                created_at
            FROM tickets
            ORDER BY created_at DESC
            LIMIT 1;
        """
        params = []

    print("SQL:", sql)
    print("PARAMS:", params)

    # --------------------------
    # Execute RDS query
    # --------------------------
    try:
        resp = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql,
            parameters=params
        )
        print("RDS RESPONSE:", json.dumps(resp))
    except Exception as e:
        print("RDS ERROR:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    rows = resp.get("records", [])
    print("ROWS:", rows)

    # --------------------------
    # No ticket found
    # --------------------------
    if not rows:
        return {
            "statusCode": 200,
            "body": json.dumps({"ticket": None})
        }

    r = rows[0]

    # --------------------------
    # Build ticket output
    # --------------------------
    ticket = {
        "id": safe(r[0]),
        "title": safe(r[1]),
        "description": safe(r[2]),
        "category": safe(r[3]),
        "created_at": safe(r[4]),
    }

    return {
        "statusCode": 200,
        "body": json.dumps({"ticket": ticket})
    }
