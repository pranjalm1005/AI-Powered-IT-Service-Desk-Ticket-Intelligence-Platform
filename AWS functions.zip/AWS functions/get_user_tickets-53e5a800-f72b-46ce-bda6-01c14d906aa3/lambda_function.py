import json
import boto3
import os

# AWS RDS Data API Client
rds = boto3.client("rds-data", region_name="us-east-1")

# Environment variables
DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN = os.environ["DB_SECRET_ARN"]
DB_NAME = os.environ["DB_NAME"]


def safe_extract(column):
    """
    Safely extract value from RDS Data API column
    """
    if not isinstance(column, dict):
        return None
    
    # Try different value types
    if "stringValue" in column:
        return column["stringValue"]
    elif "longValue" in column:
        return column["longValue"]
    elif "doubleValue" in column:
        return column["doubleValue"]
    elif "booleanValue" in column:
        return column["booleanValue"]
    elif "isNull" in column and column["isNull"]:
        return None
    
    return None


def lambda_handler(event, context):
    """
    Get all tickets for a specific user
    """
    
    print("GET USER TICKETS EVENT:", json.dumps(event))
    
    # Parse input
    if "body" in event:
        try:
            body = json.loads(event["body"])
        except:
            body = event
    else:
        body = event
    
    user_email = body.get("user_email", "").strip()
    
    if not user_email:
        return {
            "statusCode": 400,
            "body": json.dumps({
                "error": "user_email is required"
            })
        }
    
    print(f"Fetching tickets for user: {user_email}")
    
    # SQL Query
    sql = """
        SELECT 
            id::text,
            title,
            description,
            category,
            status,
            user_email,
            created_at::text,
            updated_at::text,
            resolved_at::text,
            resolved_by,
            user_resolution_steps,
            it_resolution_steps
        FROM tickets
        WHERE LOWER(user_email) = LOWER(:email)
        ORDER BY created_at DESC;
    """
    
    params = [
        {"name": "email", "value": {"stringValue": user_email}}
    ]
    
    try:
        response = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql,
            parameters=params
        )
        
        print(f"RDS Response: {response}")
        
    except Exception as e:
        print(f"DATABASE ERROR: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": f"Database error: {str(e)}"
            })
        }
    
    # Parse results
    tickets = []
    for record in response.get("records", []):
        try:
            ticket = {
                "id": safe_extract(record[0]),
                "title": safe_extract(record[1]),
                "description": safe_extract(record[2]),
                "category": safe_extract(record[3]),
                "status": safe_extract(record[4]),
                "user_email": safe_extract(record[5]),
                "created_at": safe_extract(record[6]),
                "updated_at": safe_extract(record[7]),
                "resolved_at": safe_extract(record[8]),
                "resolved_by": safe_extract(record[9]),
                "user_resolution_steps": safe_extract(record[10]) or "No steps recorded",
                "it_resolution_steps": safe_extract(record[11]) or "No IT steps recorded"
            }
            tickets.append(ticket)
        except Exception as e:
            print(f"Error parsing record: {e}")
            continue
    
    print(f"Found {len(tickets)} tickets for {user_email}")
    
    return {
        "statusCode": 200,
        "body": json.dumps({
            "tickets": tickets,
            "count": len(tickets),
            "user_email": user_email
        })
    }