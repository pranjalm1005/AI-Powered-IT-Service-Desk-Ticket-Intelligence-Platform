import json
import boto3
import os

rds = boto3.client("rds-data")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]


def safe_val(col):
    if "stringValue" in col:
        return col["stringValue"]
    if "booleanValue" in col:
        return col["booleanValue"]
    if "longValue" in col:
        return col["longValue"]
    if "doubleValue" in col:
        return col["doubleValue"]
    return None  


def lambda_handler(event, context):

    sql = """
        SELECT 
            id,
            title,
            description,
            category,
            status,
            user_email,
            created_at,
            resolved_at,
            resolved_by,
            last_update,
            user_resolution_steps,
            it_resolution_steps
        FROM tickets
        ORDER BY created_at DESC;
    """

    resp = rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
    )

    rows = resp.get("records", [])

    tickets = []
    for r in rows:
        tickets.append({
            "id": safe_val(r[0]),
            "title": safe_val(r[1]),
            "description": safe_val(r[2]),
            "category": safe_val(r[3]),
            "status": safe_val(r[4]),
            "user_email": safe_val(r[5]),
            "created_at": safe_val(r[6]),
            "resolved_at": safe_val(r[7]),
            "resolved_by": safe_val(r[8]),
            "last_update": safe_val(r[9]),
            "user_resolution_steps": safe_val(r[10]) or "",
            "it_resolution_steps": safe_val(r[11]) or "",
        })

    return {
        "statusCode": 200,
        "body": json.dumps({"tickets": tickets})
    }
