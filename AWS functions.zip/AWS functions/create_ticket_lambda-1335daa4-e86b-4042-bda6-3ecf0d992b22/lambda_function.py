import json
import boto3
import os
import random
import string

# ------------------------------
# AWS Clients
# ------------------------------
rds = boto3.client("rds-data")
bedrock = boto3.client("bedrock-runtime")

# ------------------------------
# Environment Variables
# ------------------------------
DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]

EMBED_MODEL = "amazon.titan-embed-text-v1"


# ================================================================
# Generate Short Ticket ID (e.g., NS123456)
# ================================================================
def generate_ticket_id():
    prefix = "NS"
    number = random.randint(100000, 999999)
    return f"{prefix}{number}"


# ================================================================
# Generate Embedding (Always 768 dims)
# ================================================================
def generate_embedding(text: str):
    try:
        response = bedrock.invoke_model(
            modelId=EMBED_MODEL,
            body=json.dumps({"inputText": text.strip()})
        )
        output = json.loads(response["body"].read())
        embedding = output["embedding"]

        # Ensure exactly 768 dims
        return embedding[:768]

    except Exception as e:
        print("Embedding generation failed:", str(e))
        # Return zero vector to avoid crashes
        return [0.0] * 768


# ================================================================
# Insert Ticket Record
# ================================================================
def insert_ticket(ticket_id, title, description, category, user_email):

    sql = """
        INSERT INTO tickets 
        (id, title, description, category, user_email, status, last_update, user_resolution_steps, it_resolution_steps)
        VALUES 
        (:id, :title, :description, :category, :email, 'open', NOW(), '', '');
    """

    rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
        parameters=[
            {"name": "id",          "value": {"stringValue": ticket_id}},
            {"name": "title",       "value": {"stringValue": title}},
            {"name": "description", "value": {"stringValue": description}},
            {"name": "category",    "value": {"stringValue": category}},
            {"name": "email",       "value": {"stringValue": user_email}},
        ]
    )


# ================================================================
# Insert Embedding Row
# ================================================================
def insert_embedding(ticket_id, embedding, category):

    vector = "[" + ",".join(str(x) for x in embedding) + "]"

    sql = """
        INSERT INTO ticket_embeddings (ticket_id, embedding, category)
        VALUES (:ticket_id, CAST(:embedding AS vector), :category);
    """

    rds.execute_statement(
        secretArn=DB_SECRET_ARN,
        resourceArn=DB_CLUSTER_ARN,
        database=DB_NAME,
        sql=sql,
        parameters=[
            {"name": "ticket_id", "value": {"stringValue": ticket_id}},
            {"name": "embedding", "value": {"stringValue": vector}},
            {"name": "category",  "value": {"stringValue": category}},
        ]
    )


# ================================================================
# MAIN LAMBDA HANDLER
# ================================================================
def lambda_handler(event, context):

    # Parse safely
    body = json.loads(event["body"]) if "body" in event else event

    title       = (body.get("title") or "").strip()
    description = (body.get("description") or "").strip()
    category    = (body.get("category") or "").strip()
    user_email  = (body.get("user_email") or "").strip().lower()

    # Validations
    if not description:
        return {"statusCode": 400, "body": json.dumps({"error": "description is required"})}

    if not user_email:
        return {"statusCode": 400, "body": json.dumps({"error": "user_email is required"})}

    if not title:
        title = description[:60]

    # Generate ticket ID
    ticket_id = generate_ticket_id()

    # Insert ticket record
    insert_ticket(ticket_id, title, description, category, user_email)

    # Generate + store embedding
    embedding = generate_embedding(description)
    insert_embedding(ticket_id, embedding, category)

    # Return
    return {
        "statusCode": 200,
        "body": json.dumps({
            "ticket_id": ticket_id,
            "status": "Ticket created successfully"
        })
    }
