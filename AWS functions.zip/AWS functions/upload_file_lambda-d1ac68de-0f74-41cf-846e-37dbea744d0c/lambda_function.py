import json
import boto3
import base64
import uuid

s3 = boto3.client("s3")
rds = boto3.client("rds-data")

BUCKET = "agentic-ticket-attachments"
CLUSTER_ARN = "arn:aws:rds:us-east-1:256041294492:cluster:agentic-assistant-db"
SECRET_ARN  = "arn:aws:secretsmanager:us-east-1:256041294492:secret:rds-db-credentials/cluster-YFFPGBNSSLO6U756KU35HHGLTU/agentic_owner/1762262844350-3MQOPl"
DB_NAME = "postgres"

def lambda_handler(event, context):

    # direct invocation test / API gateway
    body = event
    if "body" in event:
        body = json.loads(event["body"])

    user_id = body["user_id"]
    ticket_id = body["ticket_id"]
    file_name = body["file_name"]
    b64 = body["file_content_base64"]

    file_bytes = base64.b64decode(b64)
    file_key = f"attachments/{uuid.uuid4()}-{file_name}"

    # upload to s3
    s3.put_object(
        Bucket=BUCKET,
        Key=file_key,
        Body=file_bytes
    )

    # insert row via Data API
    rds.execute_statement(
        secretArn=SECRET_ARN,
        resourceArn=CLUSTER_ARN,
        database=DB_NAME,
        sql="""
            INSERT INTO attachments (ticket_id, s3_key, file_name)
            VALUES (:ticket_id::uuid, :s3_key, :file_name)
        """,
        parameters=[
            {"name": "ticket_id", "value": {"stringValue": ticket_id}},
            {"name": "s3_key", "value": {"stringValue": file_key}},
            {"name": "file_name", "value": {"stringValue": file_name}},
        ]
    )

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "uploaded": True,
            "s3_key": file_key
        })
    }
