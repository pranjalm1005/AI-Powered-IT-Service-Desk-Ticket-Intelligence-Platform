import json
import boto3
import os

rds = boto3.client("rds-data", region_name="us-east-1")

DB_CLUSTER_ARN = os.environ["DB_CLUSTER_ARN"]
DB_SECRET_ARN  = os.environ["DB_SECRET_ARN"]
DB_NAME        = os.environ["DB_NAME"]

def safe(col):
    if not isinstance(col, dict):
        return None
    return (
        col.get("stringValue")
        or col.get("longValue")
        or col.get("doubleValue")
        or None
    )

def lambda_handler(event, context):

    print("EVENT:", event)

    # -----------------------------
    # Build SQL
    # -----------------------------
    sql = """
        SELECT
            id::text,
            title,
            description,
            category,
            status,
            user_email,
            created_at,
            updated_at,
            resolved_at,
            last_update
        FROM tickets
        WHERE status = 'resolved'
           OR resolved_at IS NOT NULL
        ORDER BY resolved_at DESC NULLS LAST, updated_at DESC;
    """

    try:
        resp = rds.execute_statement(
            secretArn=DB_SECRET_ARN,
            resourceArn=DB_CLUSTER_ARN,
            database=DB_NAME,
            sql=sql
        )

    except Exception as e:
        print("ERROR:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    rows = resp.get("records", [])
    resolved_list = []

    for r in rows:
        resolved_list.append({
            "id": safe(r[0]),
            "title": safe(r[1]),
            "description": safe(r[2]),
            "category": safe(r[3]),
            "status": safe(r[4]),
            "user_email": safe(r[5]),
            "created_at": safe(r[6]),
            "updated_at": safe(r[7]),
            "resolved_at": safe(r[8]),
            "last_update": safe(r[9]),
        })

    return {
        "statusCode": 200,
        "body": json.dumps({"resolved_tickets": resolved_list})
    }
